define(function() {
    
    function Provider(providerId, providerName) {
        this.providerId = providerId;
        this.providerName = providerName;
    }
    
    return Provider;
});